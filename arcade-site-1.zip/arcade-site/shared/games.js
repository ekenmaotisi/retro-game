/* The catalogue. To add a game: put its folder in /games/<id>/ and add one entry below. */
window.SITE = {
  name: 'JAMBO ARCADE',          // working name: change in one place when you pick the final brand
  tagline: 'Quick games for your phone. No download.'
};

window.GAMES = [
  {
    id: 'bumpa',
    title: 'BUMPA',
    tagline: 'Bounce, shrink, grow. Reach the flag.',
    path: 'games/bumpa/',
    status: 'live'
  },
  {
    id: 'game2',
    title: 'GAME 2',
    tagline: 'Coming soon',
    path: '',
    status: 'soon'
  }
];
