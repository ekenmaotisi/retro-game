/* Shared platform code. Every game page loads this file.
   It handles: personal bests, share button, visit tracking, analytics events.
   Games never talk to an analytics service directly; they call Platform.track(). */
(function () {
  'use strict';
  var NS = 'arcade.';

  var store = {
    get: function (k, d) {
      try { var v = localStorage.getItem(NS + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; }
    },
    set: function (k, v) {
      try { localStorage.setItem(NS + k, JSON.stringify(v)); } catch (e) {}
    }
  };

  function today() { return new Date().toISOString().slice(0, 10); }

  var P = {
    debug: false,
    store: store,

    // Send an event to analytics (Umami, once its script tag is added) and keep a local count.
    track: function (name, props) {
      try { if (window.umami && typeof window.umami.track === 'function') window.umami.track(name, props || {}); } catch (e) {}
      try { var c = store.get('events', {}); c[name] = (c[name] || 0) + 1; store.set('events', c); } catch (e) {}
      if (P.debug) console.log('[track]', name, props);
    },

    getBest: function (id) { return store.get('best.' + id, 0); },

    submitScore: function (id, score) {
      var best = P.getBest(id);
      var isNew = score > best;
      if (isNew) store.set('best.' + id, score);
      return { best: Math.max(best, score), isNew: isNew };
    },

    share: function (opts) {
      var url = opts.url || location.href.split('#')[0].split('?')[0];
      try { var u = new URL(url); u.searchParams.set('ref', 'share'); url = u.toString(); } catch (e) {}
      P.track('share', { game: opts.game });
      if (navigator.share) {
        navigator.share({ title: opts.title || document.title, text: opts.text, url: url }).catch(function () {});
      } else {
        window.open('https://wa.me/?text=' + encodeURIComponent(opts.text + ' ' + url), '_blank');
      }
    },

    // Call once per page load. Tracks first visits, return visits (new day) and visits from shared links.
    recordVisit: function () {
      var t = today();
      var v = store.get('visit', { first: t, last: null, days: 0 });
      if (v.last !== t) {
        v.days += 1; v.last = t; store.set('visit', v);
        P.track(v.days > 1 ? 'return_visit' : 'first_visit', { day_number: v.days });
      }
      try {
        if (new URLSearchParams(location.search).get('ref') === 'share') P.track('referral_visit');
      } catch (e) {}
    }
  };

  window.Platform = P;
})();
